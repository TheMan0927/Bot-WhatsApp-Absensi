import { readFileSync, writeFileSync, existsSync } from 'fs';
import { CONFIG } from '../config.js';

export const storage = {
  absensi: {
    load: () => existsSync(CONFIG.PATHS.ABSENSI) 
      ? JSON.parse(readFileSync(CONFIG.PATHS.ABSENSI)) 
      : [],
    save: (data) => writeFileSync(CONFIG.PATHS.ABSENSI, JSON.stringify(data, null, 2))
  },
  
  groups: {
    load: () => existsSync(CONFIG.PATHS.GROUPS) 
      ? JSON.parse(readFileSync(CONFIG.PATHS.GROUPS)) 
      : CONFIG.ALLOWED_GROUPS,
    save: (data) => writeFileSync(CONFIG.PATHS.GROUPS, JSON.stringify(data, null, 2))
  }
};