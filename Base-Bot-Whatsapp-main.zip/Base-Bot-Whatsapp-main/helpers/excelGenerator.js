import XLSX from 'xlsx';

export const generateExcel = (absensi) => {
  const worksheet = XLSX.utils.json_to_sheet(absensi.map(entry => ({
    'ID Absensi': entry.id,
    'Nama Siswa': entry.nama,
    'Kelas': entry.kelas,
    'Waktu Absen': entry.waktu,
    'Nomor WhatsApp': entry.user.replace(/@s\.whatsapp\.net/g, '')
  })));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Absensi');
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
};