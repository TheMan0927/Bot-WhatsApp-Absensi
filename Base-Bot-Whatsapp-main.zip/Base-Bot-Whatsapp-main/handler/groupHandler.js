import { storage } from '../helpers/storage.js';
import moment from 'moment';

export const groupHandler = {
  validateGroup: (jid) => {
    const allowedGroups = storage.groups.load();
    return allowedGroups.includes(jid);
  },

  addGroup: (jid) => {
    const groups = storage.groups.load();
    if (!groups.includes(jid)) {
      groups.push(jid);
      storage.groups.save(groups);
    }
  }
};