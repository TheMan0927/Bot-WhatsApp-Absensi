import { storage } from '../helpers/storage.js';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';

export const userHandler = {
  handleAbsen: (userData) => {
    const absensi = storage.absensi.load();
    
    // Cek absensi ganda
    const existing = absensi.find(a => 
      a.user === userData.user && 
      moment(a.waktu).isSame(moment(), 'day')
    );

    if (existing) {
      return { error: 'Anda sudah absen hari ini!', data: existing };
    }

    // Buat absensi baru
    const newAbsen = {
      id: uuidv4(),
      ...userData,
      waktu: moment().format('YYYY-MM-DD HH:mm:ss')
    };

    absensi.push(newAbsen);
    storage.absensi.save(absensi);
    return { success: true, data: newAbsen };
  }
};