import { storage } from '../helpers/storage.js';
import { generateExcel } from '../helpers/excelGenerator.js';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';

export const adminHandler = {
  handleExport: async (sock, jid) => {
    try {
      const absensi = storage.absensi.load();
      const buffer = generateExcel(absensi);
      
      await sock.sendMessage(jid, {
        document: buffer,
        fileName: `absensi_${moment().format('YYYYMMDD_HHmmss')}.xlsx`,
        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
    } catch (error) {
      await sock.sendMessage(jid, { text: 'Gagal membuat laporan: ' + error.message });
    }
  },

  handleEdit: (id, newData) => {
    const absensi = storage.absensi.load();
    const index = absensi.findIndex(a => a.id === id);
    
    if (index > -1) {
      absensi[index] = { ...absensi[index], ...newData };
      storage.absensi.save(absensi);
      return true;
    }
    return false;
  },

  handleDelete: (id) => {
    const absensi = storage.absensi.load();
    const newData = absensi.filter(a => a.id !== id);
    
    if (newData.length !== absensi.length) {
      storage.absensi.save(newData);
      return true;
    }
    return false;
  }
};