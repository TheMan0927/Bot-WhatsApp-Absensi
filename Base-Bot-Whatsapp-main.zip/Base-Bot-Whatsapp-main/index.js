import { makeWASocket, useSingleFileAuthState } from '@whiskeysockets/baileys';
import { CONFIG } from './config.js';
import { groupHandler } from './handlers/groupHandler.js';
import { adminHandler } from './handlers/adminHandler.js';
import { userHandler } from './handlers/userHandler.js';
import { storage } from './helpers/storage.js';
import moment from 'moment';

const { state, saveState } = useSingleFileAuthState('./auth_info.json');
const sock = makeWASocket({
  auth: state,
  printQRInTerminal: true
});

// Event Handling
sock.ev.on('connection.update', (update) => {
  if (update.connection === 'open') {
    console.log('Bot terhubung sebagai:', sock.user?.id);
    storage.groups.save(storage.groups.load()); // Init group data
  }
});

sock.ev.on('messages.upsert', async ({ messages }) => {
  const msg = messages[0];
  if (!msg.message || msg.key.remoteJid === 'status@broadcast') return;

  const jid = msg.key.remoteJid;
  const isGroup = jid.endsWith('@g.us');
  const userNumber = msg.key.participant || msg.key.remoteJid;
  const message = msg.message.conversation || '';

  // Group Validation
  if (isGroup && !groupHandler.validateGroup(jid)) {
    await sock.sendMessage(jid, { text: 'Grup tidak terdaftar!' });
    return;
  }

  try {
    // Admin Commands
    if (userNumber === CONFIG.ADMIN_NUMBER) {
      if (message.startsWith('!addgroup')) {
        groupHandler.addGroup(jid);
        await sock.sendMessage(jid, { text: 'Grup berhasil didaftarkan!' });
      }

      if (message === '!export') {
        await adminHandler.handleExport(sock, jid);
      }

      if (message.startsWith('!editabsen')) {
        const [, id, nama, kelas] = message.split('#');
        const success = adminHandler.handleEdit(id, { nama, kelas });
        await sock.sendMessage(jid, { 
          text: success ? 'Absen berhasil diupdate!' : 'ID absen tidak valid' 
        });
      }

      if (message.startsWith('!hapusabsen')) {
        const [, id] = message.split('#');
        const success = adminHandler.handleDelete(id);
        await sock.sendMessage(jid, { 
          text: success ? 'Absen berhasil dihapus!' : 'ID absen tidak ditemukan' 
        });
      }
    }

    // User Command: !absen#Nama#Kelas
    if (message.startsWith('!absen')) {
      const [, nama, kelas] = message.split('#');
      const result = userHandler.handleAbsen({ 
        user: userNumber, 
        nama: nama?.trim(), 
        kelas: kelas?.trim()
      });

      if (result.error) {
        await sock.sendMessage(jid, { 
          text: `${result.error}\nTerakhir absen: ${result.data.waktu}`
        });
      } else {
        await sock.sendMessage(jid, { 
          text: `Absen berhasil!\nID: ${result.data.id}\nWaktu: ${result.data.waktu}`
        });
      }
    }
  } catch (error) {
    console.error('Error:', error);
    await sock.sendMessage(jid, { text: 'Terjadi kesalahan sistem!' });
  }
});

// Session Saving
sock.ev.on('creds.update', saveState);