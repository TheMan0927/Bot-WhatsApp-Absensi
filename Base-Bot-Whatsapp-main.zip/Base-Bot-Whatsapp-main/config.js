import { join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

export const CONFIG = {
  ADMIN_NUMBER: '628xxxxxxx@s.whatsapp.net',
  ALLOWED_GROUPS: [], // Akan terisi dari file groups.json
  PATHS: {
    DATA: join(__dirname, 'data'),
    ABSENSI: join(__dirname, 'data/absensi.json'),
    GROUPS: join(__dirname, 'data/groups.json')
  }
};